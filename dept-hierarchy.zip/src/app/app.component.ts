import { Component } from '@angular/core';
import { Department } from './department-hierarchy-recursive/model';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent 
{
    postComments: any[];
    departments: Department[];

    getJsonData: boolean = false;

    parent: any;
    parent_id: number;

	constructor()
	{
        this.parent = null;
        this.parent_id = null;

        this.departments = [];

        // this.departments = [
        //     { "value": "Hospital", "has_sub_category": true, "parent_id": null, "parent_name": null, showTemplate: false, 
        //         children: 
        //         [
        //             { "value": "OPD", "has_sub_category": true, "parent_id": 1, "parent_name": "Hospital", "showTemplate": false, 
        //                 children: 
        //                 [
        //                     { "value": "Dental", "has_sub_category": false, "parent_id": 2, "parent_name": "OPD", "showTemplate": false, children: [] },
        //                     { "value": "Cardialogy", "has_sub_category": false, "parent_id": 2, "parent_name": "OPD", "showTemplate": false, children: [] }, 
        //                     { "value": "ENT", "has_sub_category": false, "parent_id": 2, "parent_name": "OPD", "showTemplate": false, children: [] }, 
        //                     { "value": "General Surgery", "has_sub_category": true, "parent_id": 2, "parent_name": "OPD", "showTemplate": false,
        //                     children: 
        //                     [
        //                         { "value": "Plastic Surgery", "has_sub_category": false, "parent_id": 6, "parent_name": "Surgery", "showTemplate": false, children: [] },
        //                         { "value": "A", "has_sub_category": false, "parent_id": 6, "parent_name": "Surgery", "showTemplate": false, children: [] }, 

        //                     ]}, 
        //                 ]
        //             }
        //         ]
        //     },
        // ];
        
        // this.departments = [
        //     { "value": "Hospital", "has_sub_category": true, "parent_id": null, "parent_name": null, "showTemplate": false },
        //     { "value": "OPD", "has_sub_category": true, "parent_id": 1, "parent_name": "Hospital", "showTemplate": false },
        //     { "value": "Dental", "has_sub_category": false, "parent_id": 2, "parent_name": "OPD", "showTemplate": false },
        //     { "value": "Cardialogy", "has_sub_category": false, "parent_id": 2, "parent_name": "OPD", "showTemplate": false }, 
        //     { "value": "ENT", "has_sub_category": false, "parent_id": 2, "parent_name": "OPD", "showTemplate": false }, 
        //     { "value": "Surgery", "has_sub_category": true, "parent_id": 2, "parent_name": "OPD", "showTemplate": false }, 
        //     { "value": "Plastic Surgery", "has_sub_category": false, "parent_id": 6, "parent_name": "Surgery", "showTemplate": false }
        // ]


        // this.departments = [
        //     { "value": "Hospital", "has_sub_category": true, "parent_id": null, "parent_name": null, showTemplate: false, level: 1,
        //         children: 
        //         [
        //             { "value": "OPD", "has_sub_category": true, "parent_id": 1, "parent_name": "Hospital", "showTemplate": false, level: 2,
        //                 children: 
        //                 [
        //                     { "value": "Dental", "has_sub_category": false, "parent_id": 2, "parent_name": "OPD", "showTemplate": false, level: 3, children: [] },
        //                     { "value": "Cardialogy", "has_sub_category": false, "parent_id": 2, "parent_name": "OPD", "showTemplate": false, level: 3, children: [] }, 
        //                     { "value": "ENT", "has_sub_category": false, "parent_id": 2, "parent_name": "OPD", "showTemplate": false, level: 3, children: [] }, 
        //                     { "value": "General Surgery", "has_sub_category": true, "parent_id": 2, "parent_name": "OPD", "showTemplate": false, level: 3,
        //                     children: 
        //                     [
        //                         { "value": "Plastic Surgery", "has_sub_category": false, "parent_id": 7, "parent_name": "Surgery", "showTemplate": false, level: 4, children: [] }
        //                     ]}, 
        //                 ]
        //             },
        //             { "value": "Test", "has_sub_category": true, "parent_id": 1, "parent_name": "Hospital", "showTemplate": false, level: 2,
        //                 children: 
        //                 [
        //                     { "value": "Test A", "has_sub_category": false, "parent_id": 3, "parent_name": "Test", "showTemplate": false, level: 2, children: [] },
        //                 ]
        //             }
        //         ]
        //     },
        // ];
    }
    
    onAddRecord(input: HTMLInputElement, hasSubCategory: HTMLInputElement, parent: any, parent_id: any): void
    {
        console.log('parent =', parent);
        console.log('Parent Id =', parent_id);

        for (let dept of this.departments)
        {
            dept.showTemplate = false;
        }

        if (parent !== null && hasSubCategory.checked)
        {
            this.parent = parent;
            this.parent_id = parent_id;

            for (let rec of this.departments)
            {
                if (rec.value === this.parent.value)
                {
                    rec.children.push({
                        value: input.value, 
                        has_sub_category: hasSubCategory.checked,
                        parent_id: this.parent_id, 
                        parent_name: this.parent ? this.parent.value : null, 
                        showTemplate: false,
                        children: []
                    })
                }
            }
        }
        else
        {
            this.departments.push({
                value: input.value, 
                has_sub_category: hasSubCategory.checked,
                parent_id: this.parent_id, 
                parent_name: this.parent ? this.parent.value : null, 
                showTemplate: false,
                children: []
            });
        }

        console.log('departments =', this.departments);
    }

    onRemoveRecord(department: Department): void
    {
        console.log('departments =', this.departments);
        console.log('Department to Delete =', department);
    }

    onShowTemplate(department: Department): void
    {
        for (let dept of this.departments)
        {
            dept.showTemplate = false;
        }

        department.showTemplate = true;
    }

    onRecursiveActions(ev: any)
    {
        console.log('ON Recursive Actions =', ev);

        for (let dept of this.departments)
        {
            console.log('Dept =', dept);
            if (dept.value === ev.parent.value)
            {
                dept.children.push({
                    value: ev.value, 
                    has_sub_category: ev.has_sub_category, 
                    parent_id: ev.parent_id, 
                    parent_name: ev.parent.value,
                    showTemplate: false, 
                    children: []
                });
            }
            else
            {
                for (let d of dept.children)
                {
                    if (d.value === ev.parent.value)
                    {
                        d.children.push({
                            value: ev.value, 
                            has_sub_category: ev.has_sub_category, 
                            parent_id: ev.parent_id, 
                            parent_name: ev.parent.value,
                            showTemplate: false, 
                            children: []
                        });
                    }
                }
            }
        }

        for (let dept of this.departments)
        {
            dept.showTemplate = false;
        }

        console.log('departments =', this.departments);
    }
    
}
