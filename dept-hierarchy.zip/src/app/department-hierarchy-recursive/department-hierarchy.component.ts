import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { Department } from './model';


@Component({
  selector: 'department-hierarchy-recursive',
  templateUrl: './department-hierarchy.component.html',
  styleUrls: ['./department-hierarchy.component.scss']
})
export class DepartmentHierarchyRecursiveComponent
{
    @Input() data: Department[];
    @Input() departments: Department[];
    @Output() actions = new EventEmitter();

    level: number;
    
    parent: any;
    parent_id: any;

	constructor()
	{
        this.data = [];
        this.departments = [];
        this.parent = null;
        this.parent_id = null;
        this.level = 0;
    }

    onAddRecord(input: HTMLInputElement, hasSubCategory: HTMLInputElement, parent: any, parent_id: any): void
    {

        for (let dept of this.data)
        {
            dept.showTemplate = false;
        }

        let dict = {value: input.value, has_sub_category: hasSubCategory.checked, parent: parent, parent_id: parent_id};

        console.log('Dict to Add =', dict);
        for (let dept of this.departments)
        {
            if (dept.value === dict.parent.value)
            {
                dept.children.push({
                    value: dict.value, 
                    has_sub_category: dict.has_sub_category, 
                    parent_id: dict.parent_id, 
                    parent_name: dict.parent.value,
                    showTemplate: false, 
                    children: []
                });
            }
            else
            {
                for (let d of dept.children)
                {
                    if (d.value === dict.parent.value)
                    {
                        d.children.push({
                            value: dict.value, 
                            has_sub_category: dict.has_sub_category, 
                            parent_id: dict.parent_id, 
                            parent_name: dict.parent.value,
                            showTemplate: false, 
                            children: []
                        });
                    }
                }
            }
        }

        for (let dept of this.departments)
        {
            dept.showTemplate = false;
        }

        console.log('departments =', this.departments);
        // this.actions.emit({value: input.value, has_sub_category: hasSubCategory.checked, parent: parent, parent_id: parent_id});
       

        // if (parent !== null && hasSubCategory.checked)
        // {
        //     this.parent = parent;
        //     this.parent_id = parent_id;

        //     for (let rec of this.data)
        //     {
        //         if (rec.value === this.parent.value)
        //         {
        //             rec.children.push({
        //                 value: input.value, 
        //                 has_sub_category: hasSubCategory.checked,
        //                 parent_id: this.parent_id, 
        //                 parent_name: this.parent ? this.parent.value : null, 
        //                 showTemplate: false,
        //                 children: []
        //             })
        //         }
        //     }
        // }
        // else
        // {
        //     this.data.push({
        //         value: input.value, 
        //         has_sub_category: hasSubCategory.checked,
        //         parent_id: this.parent_id, 
        //         parent_name: this.parent ? this.parent.value : null, 
        //         showTemplate: false,
        //         children: []
        //     });
        // }

        // console.log('Adding  Data in Recursive Comp =', this.data);

        // if (input.value !== null && input.value !== '')
        // {
        //     if (parent !== null)
        //     {
        //         this.parent = parent;
        //         this.parent_id = parent_id;

        //         if (this.parent_id !== null && this.parent_id == 0)
        //         {
        //             this.parent_id = this.parent_id + 1;
        //         }

        //         for (let rec of this.data)
        //         {
        //             if (rec.value === this.parent)
        //             {
        //                 rec.children.push({
        //                     value: input.value, 
        //                     has_sub_category: hasSubCategory.checked,
        //                     parent_id: this.parent_id, 
        //                     parent_name: this.parent ? this.parent.value : null, 
        //                     showTemplate: false,
        //                     children: []
        //                 })
        //             }
        //         }
        //     }
        //     else
        //     {
        //         this.data.push({
        //             value: input.value, 
        //             has_sub_category: hasSubCategory.checked,
        //             parent_id: this.parent_id, 
        //             parent_name: this.parent ? this.parent.value : null, 
        //             showTemplate: false,
        //             children: []
        //         });
        //     }
        // }
    }

    onRemoveRecord(department: Department): void
    {
        console.log('Data =', this.data);
        console.log('Department to Delete =', department);
    }

    onShowTemplate(department: Department): void
    {
        for (let dept of this.data)
        {
            dept.showTemplate = false;
        }

        department.showTemplate = true;
    }
    
    getMarginLeft(dept: Department)
    {
        let margin: number = 20;

        if (dept.parent_id === null)
        {
            return 0;
        }

        if (dept.has_sub_category)
        {
            this.level += 1;
            margin *= this.level;
        }
        else
        {
            margin += 40;
        }
        
        return margin;
    }  

    getPadding(dept: Department)
    {
        if (dept.has_sub_category)
        {
            return 10
        }

        return 0;
    }    

    getBackgroundColor(dept: Department)
    {
        let backgroundColor = "";

        if (dept.has_sub_category && dept.parent_id !== null)
        {
            backgroundColor = this.getRandomColor();
        }

        return backgroundColor;
    }

    getRandomColor() 
    {
        const letters = '0123456789ABCDEF';
        let color = '#';
        for (let i = 0; i < 6; i++) {
          color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    }
}
