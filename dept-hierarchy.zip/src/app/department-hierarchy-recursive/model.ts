export interface Department
{
    value: string;
    parent_id: number;
    parent_name: string;
    has_sub_category: boolean;
    showTemplate: boolean;
    
    children: Department[];
}